PHP_ARG_ENABLE([bar], [whether to enable bar support])
