PHP_ARG_ENABLE([apcu], [whether to enable apcu], [AS_HELP_STRING([--enable-apcu], [Enable apcu])])
