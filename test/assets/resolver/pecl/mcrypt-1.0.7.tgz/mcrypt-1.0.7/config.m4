PHP_ARG_WITH([mcrypt], [for mcrypt support], [AS_HELP_STRING([--with-mcrypt], [Include mcrypt support])])
